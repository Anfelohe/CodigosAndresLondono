package pets;

public class Dog {
    //Atributos
    String Breed, Size, Color; 
    int Age;
    
    //Getters y Setters
    public String getSize() {
        return Size;
    }
    public void setSize(String Size) {
        this.Size = Size;
    }
    public int getAge() {
        return Age;
    }
    public void setAge(int Age) {
        this.Age = Age;
    }
    
    //Constructor
    public Dog(String Breed, String Size, String Color, int Age){
        this.Breed = Breed;
        this.Size = Size;
        this.Color = Color;
        this.Age = Age;
    }
    
    
      
}
