
package app.udcpoo20232;
import pets.Dog;

public class App {
    public static void main(String[] args){
        System.out.println("Hola Mundo...");
        
        Dog sasha = new Dog("shihtzu","small","Black and White",3);
        System.out.println("La edad de Sasha es de: "+sasha.getAge());
        
        
        
        
        /*  System.out.println(args[2]);
            System.out.println(args[1]);
            System.out.println(args[0]); */
        
    }
}
