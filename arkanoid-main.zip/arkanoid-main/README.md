# ARKANOID

- KEVIN ANDRES GOMEZ MEZA - 0222220034
- MATEO GUERRERO MORALES - 0222220015
- ANDRES FELIPE LONDOÑO HERRERA - 0222220003

### Restricciones

---

1. Solo se aplican los cambios de numero de pelotas en cada nueva partida.

2. El puntaje se calcula de la siguente manera `puntaje / tiempo (en minutos)`. De tal manera el que menor tiempo demore jugando tendra mayor beneficio.
