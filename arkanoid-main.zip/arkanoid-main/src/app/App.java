/*
 * KEVIN ANDRES GOMEZ MEZA - 0222220034
 * MATEO GUERRERO MORALES - 02222220015
 * ANDRES FELIPE LONDOÑO HERRERA - 0222220003
 */
package app;

import arkanoid.board.Board;
public class App {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Board b = new Board();
        b.setVisible(true); 
    }
    
}
